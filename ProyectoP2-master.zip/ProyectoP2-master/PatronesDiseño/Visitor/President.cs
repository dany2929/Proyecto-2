﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Visitor
{
    class President : Employee

    {
        // Constructor

        public President()
          : base("Dick", 45000.0, 21)
        {
        }
    }
}
