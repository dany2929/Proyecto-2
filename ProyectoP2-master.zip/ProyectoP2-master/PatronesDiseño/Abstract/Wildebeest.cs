﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstract
{
    class Wildebeest : Herbivore

    {
    }
}
