﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstract
{
    abstract class Herbivore

    {
    }
}
